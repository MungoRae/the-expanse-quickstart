<h1>The Expanse - Quickstart</h1>
            <p>Green Ronin Publishing is proud to present the Foundry module of The Quickstart for <i>The Expanse RPG</i>! In this module, you will find everything you need to get started with your first game of The Expanse RPG.</p>
            <h2>Contents</h2>
            <ul>
            <li><b>6 Pregen Characters</li>
            <li>6 NPCs</li>
            <li>Weapons</li>
            <li>Talents</li>
            <li>Stunts</li>
            <li>Introductory Rules</li>
            <li>The Cupbearer Starter Adventure</li>
            <li>The Churn Tracker and Ship Tracking Scenes</b></li>
            </ul>
            <h2></h2>
            
<p>No part of this publication may be reproduced, distributed, stored in a retrieval system, or transmitted in any form by any means, electronic, mechanical, photocopying, recording or otherwise without the prior permission of the publishers.<br><br></p>

<p><i>The Expanse Roleplaying Game</i> is ©2019 Green Ronin Publishing, LLC. All rights reserved. First Printing. References to other copyrighted material
            in no way constitute a challenge to the respective copyright holders of that material. Green Ronin, <i>The Expanse Roleplaying Game</i>,
            and their associated logos are trademarks of Green Ronin Publishing, LLC. The Expanse is © 2011-2019 Daniel Abraham and Ty Franck.</br>


Published by: <b>Green Ronin Publishing</b>

Foundry System by: <b>Charlotte Hamilton (Foxfyre)</b><br>

<a href="mailto:letsplay@greenronin.com"></a></p>
